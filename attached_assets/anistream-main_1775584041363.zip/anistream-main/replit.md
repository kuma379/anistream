# AniStream Workspace

## Overview

Full-stack anime & film streaming website. Frontend is a Netflix-style dark React app. Backend is an Express API that proxies/fetches from an external JSON API.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM (not used in current build)
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Artifacts

### anime-stream (Frontend)
- **Type**: react-vite
- **Preview path**: `/`
- **Tech**: React + Vite + Tailwind CSS + Framer Motion + wouter + React Query
- **Description**: Netflix-style dark streaming UI

Pages:
- `/` — Home with hero banner and horizontal scroll rows (anime, films, donghua)
- `/search` — Search page with live results
- `/catalog` — Browse with filters (type, status, order)
- `/genre` — Genre list
- `/genre/:slug` — Genre detail
- `/schedule` — Airing schedule by day (Senin-Minggu)
- `/anime/:slug` — Anime detail + episode list
- `/series/:slug` — Series detail + episode list
- `/film/:slug` — Film detail + watch button
- `/episode/:slug` — Video player with server selector
- `/list/:category` — Category pages

### api-server (Backend)
- **Type**: api
- **Preview path**: `/api`
- **Tech**: Express 5 + TypeScript + Axios + Cheerio
- **Description**: Proxy API that fetches from external JSON API

Data Source: `https://www.sankavollerei.com/anime/winbu/`

API Endpoints:
- `GET /api/anime/home` — Home page data (top10 anime/film, latest, series)
- `GET /api/anime/search?q=QUERY` — Search
- `GET /api/anime/list?category=film&page=1` — Category listing
- `GET /api/anime/catalog?title=...&order=...&type=...&status=...` — Filtered catalog
- `GET /api/anime/genres` — All genres
- `GET /api/anime/genre/:slug` — By genre
- `GET /api/anime/schedule?day=senin` — Schedule
- `GET /api/anime/detail/:slug?type=anime|series|film` — Detail page
- `GET /api/anime/episode/:slug` — Episode data + streaming servers
- `GET /api/anime/server?post=...&nume=...&type=...` — Video embed URL

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks from OpenAPI spec
- `pnpm --filter @workspace/api-server run dev` — run API server locally
- `pnpm --filter @workspace/anime-stream run dev` — run frontend locally

## Architecture Notes

- Scraper uses JSON API directly (no HTML scraping for listing/detail)
- Episode HTML scraping (via Cheerio on winbu.net) is used to extract streaming server post IDs
- The `/server` endpoint returns the embed URL for the video player iframe
- All images come from winbu.net CDN
